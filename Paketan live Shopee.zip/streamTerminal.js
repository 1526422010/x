import ffmpeg from "fluent-ffmpeg";
import fetch from "node-fetch";
import readlineSync from "readline-sync";
import chalk from "chalk";
import sharp from "sharp";
import delay from 'delay';
import fs from 'fs';
import terminalImage from 'terminal-image';
import url from 'url';

(async () => {
    const tautan = readlineSync.question('[!] Tautan    : ');
    const keyStream = readlineSync.question('[!] Keystream : ');
    const nameFile = readlineSync.question('[!] File MP4  : ')
    const inputVideo = nameFile;
    const outputRTMP = ''+tautan+''+keyStream+'';
    const parsedUrl = url.parse(outputRTMP, true);

    // Ambil nilai dari parameter session_id
    const session = parsedUrl.query.session_id;
    const command = ffmpeg()
        .input(inputVideo)
        .inputOption('-stream_loop -1')
        .output(outputRTMP)
        .videoCodec('libx264')
        .audioCodec('aac')
        .fps(30)
        .videoBitrate('2000k')
        .audioBitrate('192k')
        .audioChannels(2)
        .audioFrequency(44100)
        .outputFormat('flv');

    command.on('start', (commandLine) => {
        console.log('ffmpeg command starting:', commandLine);
    });

    command.on('progress', async (progress) => {
        console.log('Processing: ' + progress.percent + '% done');
        console.log(chalk.yellow(`SessionID: ${session}`));
    });

    command.on('end', () => {
        console.log('Pemrosesan selesai');
    });

    command.on('error', (err) => {
        console.error('Error:', err);
    });

    command.run();

})();